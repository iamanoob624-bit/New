package fuzs.leavesbegone;

import net.minecraft.block.Block;
import net.minecraft.block.BlockLeaves;
import net.minecraft.block.BlockLog;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.oredict.OreDictionary;

public class LeafDecayHandler {

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public void onBlockBreak(BlockEvent.BreakEvent event) {
        World world = event.getWorld();
        if (world.isRemote) {
            return;
        }

        IBlockState brokenState = event.getState();
        if (!isLog(brokenState)) {
            return;
        }

        BlockPos origin = event.getPos();
        int radius = ServerConfig.decaySearchRadius;
        int delay = ServerConfig.decayDelayTicks;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    BlockPos pos = origin.add(dx, dy, dz);
                    IBlockState state = world.getBlockState(pos);
                    Block block = state.getBlock();

                    if (isLeaves(block, state)) {
                        // This does not decide decay itself - it just makes the leaf
                        // block's own updateTick() run sooner than a random tick would,
                        // exactly the same logic vanilla (or a mod's own leaf block)
                        // already uses to check "am I still connected to a log".
                        world.scheduleUpdate(pos, block, delay);
                    }
                }
            }
        }
    }

    private boolean isLog(IBlockState state) {
        Block block = state.getBlock();
        if (block instanceof BlockLog) {
            return true;
        }
        return matchesOreDictionary(block, state, "logWood");
    }

    private boolean isLeaves(Block block, IBlockState state) {
        if (block instanceof BlockLeaves) {
            return true;
        }
        if (matchesOreDictionary(block, state, "treeLeaves")) {
            return true;
        }
        if (!ServerConfig.strictLeafMatching) {
            String registryName = block.getRegistryName() != null ? block.getRegistryName().toString() : "";
            return registryName.toLowerCase().contains("leaves");
        }
        return false;
    }

    private boolean matchesOreDictionary(Block block, IBlockState state, String targetName) {
        try {
            ItemStack stack = new ItemStack(block, 1, block.getMetaFromState(state));
            if (stack.isEmpty()) {
                return false;
            }
            int[] ids = OreDictionary.getOreIDs(stack);
            for (int id : ids) {
                if (OreDictionary.getOreName(id).equals(targetName)) {
                    return true;
                }
            }
        } catch (Exception ignored) {
            // Some blocks don't have a valid item form (e.g. certain multi-block or
            // technical blocks) - just skip the OreDictionary check for those.
        }
        return false;
    }
}
