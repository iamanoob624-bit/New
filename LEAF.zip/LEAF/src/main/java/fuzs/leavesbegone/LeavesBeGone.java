package fuzs.leavesbegone;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Config;
import net.minecraftforge.common.config.ConfigManager;
import net.minecraftforge.fml.client.event.ConfigChangedEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.apache.logging.log4j.Logger;

/**
 * A clean-room reimplementation, for Minecraft 1.12.2 / Forge, of the same end-user
 * behavior described by Fuzs's "Leaves Be Gone" (MPL-2.0, https://github.com/Fuzss/leavesbegone):
 * leaves decay almost immediately after the tree they're attached to is chopped down.
 *
 * This is NOT a line-by-line port of the original 1.20.1 source (that wasn't available
 * to work from - only the compiled jar was, and no working decompiler was available in
 * the environment this was built in). Instead, this recreates the described behavior
 * using 1.12.2's own equivalent building blocks:
 *   - World#scheduleUpdate(pos, block, delay) is the direct 1.12.2 analogue of the
 *     "native scheduled tick system" the original mod says it relies on for surviving
 *     chunk unload/reload - vanilla already persists the scheduled-tick queue in each
 *     chunk's NBT, so no custom chunk-serialization Mixin is needed here.
 *   - Scheduling a tick just makes a leaf block run its own Block#updateTick sooner
 *     than a random tick normally would; the actual "am I still near a log" decay
 *     check is entirely vanilla's (or whatever modded leaf block's) own logic, exactly
 *     as the original mod describes doing.
 *   - OreDictionary's "logWood" / "treeLeaves" entries stand in for the modern
 *     "minecraft:logs" / "minecraft:leaves" tags used by the 1.20.1 original, since
 *     1.12.2 predates the block-tag system.
 *
 * See LeafDecayHandler for the actual logic.
 */
@Mod(modid = LeavesBeGone.MOD_ID, name = LeavesBeGone.NAME, version = LeavesBeGone.VERSION,
        acceptedMinecraftVersions = "[1.12.2]")
public class LeavesBeGone {
    public static final String MOD_ID = "leavesbegone";
    public static final String NAME = "Leaves Be Gone";
    public static final String VERSION = "1.12.2-port-1.0.0";
    public static Logger LOGGER;

    @Mod.Instance(MOD_ID)
    public static LeavesBeGone INSTANCE;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        LOGGER = event.getModLog();
        ConfigManager.sync(MOD_ID, Config.Type.INSTANCE);
        MinecraftForge.EVENT_BUS.register(new LeafDecayHandler());
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onConfigChanged(ConfigChangedEvent.OnConfigChangedEvent event) {
        if (event.getModID().equals(MOD_ID)) {
            ConfigManager.sync(MOD_ID, Config.Type.INSTANCE);
        }
    }
}
