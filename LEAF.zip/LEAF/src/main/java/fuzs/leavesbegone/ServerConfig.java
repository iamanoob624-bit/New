package fuzs.leavesbegone;

import net.minecraftforge.common.config.Config;

@Config(modid = LeavesBeGone.MOD_ID, name = LeavesBeGone.MOD_ID, category = "")
public class ServerConfig {

    @Config.Comment({"Radius (in blocks) around a broken log to search for leaves to check for decay.",
            "Larger values catch bigger canopies but cost a little more per log broken."})
    @Config.RangeInt(min = 1, max = 32)
    public static int decaySearchRadius = 8;

    @Config.Comment("Delay, in ticks, before a nearby leaf's decay check runs after a log is broken (20 ticks = 1 second).")
    @Config.RangeInt(min = 0, max = 200)
    public static int decayDelayTicks = 2;

    @Config.Comment("If true, only checks blocks that are an exact BlockLeaves instance or registered under the " +
            "OreDictionary 'treeLeaves' entry. If false, also allows any block whose registry name contains " +
            "\"leaves\" as a fallback for unusual modded leaf blocks.")
    public static boolean strictLeafMatching = true;
}
