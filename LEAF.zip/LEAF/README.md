# Leaves Be Gone — 1.12.2 reimplementation (for private use)

This recreates the end-user behavior of Fuzs's **Leaves Be Gone**
(https://github.com/Fuzss/leavesbegone, MPL-2.0) for Minecraft 1.12.2 / Forge:
leaves decay almost instantly after the tree they're attached to is chopped down.

## Important: this is a clean-room reimplementation, not a ported copy

Only the compiled 1.20.1 jar was provided, not its source, and the sandbox this was
built in has no working Java decompiler and no internet access to fetch one. Rather
than guess at 1.20.1 bytecode, this was built from the horse's mouth: the mod's own
public description of *how* it works ("hooks directly into Minecraft's existing leaf
decay system", "uses Minecraft's native scheduled tick system"), reimplemented against
1.12.2's own equivalent APIs from scratch. The code itself is original, written for
this port — it doesn't reuse or transcribe any of Fuzs's actual source.

This also sidesteps two things that made the previous two ports harder:
- **No Mixin needed.** 1.12.2's `World#scheduleUpdate(pos, block, delay)` is a public,
  ordinary API — no engine-internals access required.
- **No PuzzlesLib needed.** The original depends on Fuzs's shared library mod for
  config/lifecycle scaffolding across Fabric/Forge/NeoForge. Since this only targets
  one loader and version, that whole abstraction layer is unnecessary — this uses
  1.12.2 Forge's own built-in `@Config` system directly.

## How it works

1. Listens for `BlockEvent.BreakEvent`. When the broken block is a log — either a
   vanilla `BlockLog` or anything registered under the OreDictionary `logWood` entry
   (the 1.12.2-era equivalent of the modern `minecraft:logs` tag, and how most modded
   trees stay compatible) — it proceeds.
2. Scans a configurable cube radius (default 8 blocks) around the broken log for
   leaves — `BlockLeaves` instances, or anything under OreDictionary's `treeLeaves`
   entry.
3. For each leaf found, calls `world.scheduleUpdate(pos, block, delay)` — this doesn't
   decide decay itself; it just makes that leaf block run its **own**
   `Block#updateTick()` sooner than a random tick normally would. The actual "am I
   still connected to a log" check is entirely vanilla's (or whatever mod's) own leaf
   logic — exactly mirroring how the original says it avoids extra calculations.
4. Because `scheduleUpdate` is vanilla's own native mechanism, the pending tick is
   automatically saved in the chunk's NBT ("TileTicks") like any other scheduled block
   update — no custom save/load code needed for it to survive a chunk unload/reload.

## What's different from the original

- **No client-side config screen.** The original has an in-game Mod Menu / YACL
  config UI (Fabric-ecosystem tools with no 1.12.2 Forge equivalent). This instead uses
  Forge 1.12.2's built-in config GUI (accessible from the mod list screen) with three
  settings: search radius, decay delay in ticks, and a strict-vs-loose leaf-matching
  toggle.
- **Simpler compatibility mechanism.** The original uses the modern `minecraft:leaves`
  /`minecraft:logs` tag system (1.13+); this uses OreDictionary, 1.12.2's equivalent,
  plus an `instanceof BlockLeaves`/`BlockLog` check as the primary path (covers the
  vast majority of vanilla and modded trees either way).
- **No "decay across different leaf types" toggle** from the original's advanced rules
  — out of scope for this pass, though it'd be a small addition if you want it (say
  so and I'll add it).

## Things to double-check once you open this in an IDE

Same caveat as before — no internet access in the environment this was built in to
compile-verify against the real 1.12.2 classes:
- `World#scheduleUpdate(BlockPos, Block, int)` — I'm fairly confident this is the
  correct 1.12.2 method name/signature, but if your IDE says otherwise, the likely
  alternate name is `scheduleBlockUpdate(BlockPos, Block, int, int)` (with an extra
  priority argument).
- `BlockEvent.BreakEvent#getWorld()/getPos()/getState()` — standard 1.12.2 API as far
  as I know.

## Building

Same process you already know from the last mod: merge `src/main/java/fuzs` and
`src/main/resources` from this zip into a copy of the **official Forge 1.12.2 MDK**
(not the hand-written `build.gradle` approach — that one hit dependency-resolution
issues last time), then `./gradlew build` from there. Ask if you want the full
step-by-step again.
